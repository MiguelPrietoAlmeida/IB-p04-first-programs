# Informática Básica Lab assignment 

This is a repository to host the code of your lab assignments
Create an appropriate directory structure to hold your project
If your assignment includes different exercises, use different directories for each

**Remember also** to remove all binary files and empty directories in the final version of the project

This text is Markdown text. To learn about Markdown, Study these references:
* [Mastering Markdown](https://guides.github.com/features/mastering-markdown/)
* [StackEdit. An On-line MarkDown Editor](https://stackedit.io/)
* [Markdown Cheatsheet](https://github.com/adam-p/markdown-here/wiki/Markdown-Cheatsheet)
